package command;

public interface IOT {
    void on();
    void off();
}
