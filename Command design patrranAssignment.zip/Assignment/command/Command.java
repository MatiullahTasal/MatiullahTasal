package command;

public interface Command {
    void excecute(String str);
}
