package command;

public class Light implements IOT{
    public void on(){
        System.out.println("the light is on");
    }

    public void off(){
        System.out.println("the light is off!");
    }
}
